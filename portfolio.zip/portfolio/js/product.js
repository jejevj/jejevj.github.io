var name = ["Macbook Pro 2017 Second", "Monitor AOC 22B2HM", "ASUS ROG ZEPHYRUS G15","Kursi Gaming Murah","Meja Murah"];
var link = ["https://tokopedia.link/h150WHBXtzb", "https://tokopedia.link/0joqn7HXtzb", "https://tokopedia.link/TAmEmyFXtzb"
,"https://tokopedia.link/9fn5ebyXtzb","https://tokopedia.link/zg4HdTzXtzb"];
var harga = ["Rp9.850.000","Rp1.330.000","Rp13.599.000","Rp335.000","Rp441.000"];
var gambar = ["https://images.tokopedia.net/img/cache/250-square/VqbcmM/2021/7/1/98b6ee09-c3df-4772-882e-7f571aa7b2ea.png","https://id-test-11.slatic.net/p/efd5596757579b21d936d1b4a3b9b583.png","https://dlcdnwebimgs.asus.com/gain/350738D0-7C30-46CA-A84A-22D71BCF5AFB/w250","https://images.tokopedia.net/img/cache/700/VqbcmM/2021/12/2/75f921a2-b0bd-4453-89c4-bf1ff880ddb3.jpg","https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcSR44sHjLmB93f641NEl9ADwXD_nN8Ksv1ay76pCkmAAkSqG1re"]
